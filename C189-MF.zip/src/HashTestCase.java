
public class HashTestCase {

	public static void main(String args[]) {
		DirectoryHash phoneHash = new DirectoryHash();
		
		phoneHash.insert("Bob", "Smith", "bsmith@somewhere.com", "555-235-1111");
		phoneHash.insert("Jane", "Williams", "jw@something.com", "555-235-1112");
		phoneHash.insert("Mohammed", "al-Salam", "mas@someplace.com", "555-235-1113");
		phoneHash.insert("Pat", "Jones", "pjones@homesweethome.com", "555-235-1114");
		phoneHash.insert("Billy", "Kidd", "billy_the_kid@nowhere.com", "555-235-1115");
		phoneHash.insert("H.", "Houdini", "houdini@noplace.com", "555-235-1116");
		phoneHash.insert("Jack", "Jones", "jjones@hill.com", "555-235-1117");
		phoneHash.insert("Jill", "Jones", "jillj@hill.com", "555-235-1118");
		phoneHash.insert("John", "Doe", "jdoe@somedomain.com", "555-235-1119");
		phoneHash.insert("Jane", "Doe", "jdoe@somedomain.com", "555-235-1120");
		
		phoneHash.search("Pat", "Jones");
		phoneHash.search("Billy", "Kidd");

		phoneHash.delete("John", "Doe");
		
		phoneHash.insert("Test", "Case", "Test_Case@testcase.com", "555-235-1121");
		phoneHash.insert("Nadezhda", "Kanachekhovskaya", "dr.nadezhda.kanacheckovskaya@somehospital.moscow.ci.ru", "555-235-1122"); 
		phoneHash.insert("Jo", "Wu", "wu@h.com", "555-235-1123");
		phoneHash.insert("Millard", "Fillmore", "millard@theactualwhitehouse.us", "555-235-1124");
		phoneHash.insert("Bob", "vanDyke", "vandyke@nodomain.com", "555-235-1125");
		phoneHash.insert("Upside", "Down", "upsidedown@rightsideup.com", "555-235-1126");
		 
		phoneHash.search("Jack", "Jones");
		phoneHash.search("Nadezhda", "Kanachekhovskaya");

		phoneHash.delete("Jill", "Jones");
		phoneHash.delete("John", "Doe");

		phoneHash.search("Jill", "Jones");
		phoneHash.search("John", "Doe");
	}

}


